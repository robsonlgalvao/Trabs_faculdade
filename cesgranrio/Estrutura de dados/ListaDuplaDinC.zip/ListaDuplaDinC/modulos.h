struct lista{
	struct lista *ant;
    int codigo;
    int status;//0 n�o repetido, 1 repetido
    struct lista *prox;
};

int opc;

int cheia(struct lista *pos){
	if (pos == NULL){
		return 1;
	}
	return 0;
}
int vazia(struct lista *ult){
	if(ult == NULL)
		return 1;
	return 0;
}
struct lista *inslista(int cod, struct lista *ult){
	struct lista *pos = (struct lista *) malloc(1 * sizeof(struct lista));
	//lista *pos= new lista;
	if (!cheia(pos)){
		pos->codigo = cod;
		pos->status = 0;
		pos->prox = NULL;
		if(ult!=NULL){
			ult->prox = pos;
			pos->ant = ult;
		}else{
			pos->ant = NULL;
		}
		
		return pos;
	}else{
		printf("A lista esta cheia.\n");
		return ult;
	}
}
struct lista *retlista(struct lista *pri, int cod){
    struct lista * aux;
    struct lista *p = pri;
	if (!vazia(pri)){
		while(p!=NULL){
			if(p->codigo == cod){
				if(p->ant == NULL && p->prox == NULL){
					aux = NULL;
				}else{
					if(p->ant==NULL){
						p->prox->ant = NULL;
						aux = p->prox;
					}else{
						if(p->prox==NULL){
							p->ant->prox = p->prox;
							aux = p->ant;					
						}else{
							p->ant->prox = p->prox;
							p->prox->ant = p->ant;
							aux	= pri;			
						}
					}
				}
				free(p);	
				return (aux);								
			}
			p = p->prox;
		}
	}else{
		printf("a lista esta Vazia ou valor nao encontrado.");
		return pri;
	}
}
void menu(void){
	printf("\n1- insere\t2- retira\t3- tempo\t4- Exibe repetidos\t5- sair\n0pcao: ");
	scanf("%d", &opc);
}

void exiberep(struct lista *aux){
    struct lista * p ,*pu= aux;
    while (pu != NULL){
        p = pu;
        int cont=1;
		while(p!=NULL){
		    if(p->status==0){
		        if(p->prox){
		            if(pu->codigo == p->prox->codigo){
		                cont++;
		                p->status = 1;
		            }
		        }
		    }
			p = p->prox;
		}
		if(cont!=1){
		    printf("\nCodigo %d  repetido  %d vezes.\n",pu->codigo,cont);
		}
        pu = pu->prox;
    }
    p=aux;
	while(p!=NULL){
		p->status = 0;
		p = p->prox;
	}
}

