#include <stdio.h>
#include <stdlib.h>


#include "modulos.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int valor;
	struct lista *ult, *pri;
	ult=NULL;
	pri=NULL;
	
	do{
		menu();
		if (opc == 1){
			printf("\n\nInforme o codig: ");
			scanf("%d", &valor);
			ult = inslista(valor,ult);
			if (pri==NULL){
				pri = ult;
			}
		}else{
			if (opc == 2){
				struct lista *pt;
				printf("\n\nInforme o codig: ");
				scanf("%d", &valor);
				pt = retlista(pri, valor);
				if(pt == NULL){
					pri = NULL;
					ult = NULL;
				}else{
					if(pt->prox == NULL){
						ult=pt;
					}else{
						pri=pt;
					}
				}
				
				if(pri == NULL){
					ult = NULL;
				}
			}else{
			    if(opc == 3){
			        //tempo();
			    }else{
			        if(opc == 4){
			            exiberep(ult);
			        }
			    }
			}
		}
		struct lista *p=pri;
		while(p!=NULL){
			printf("%d \n",p->codigo);
			p = p->prox;
		}
	}while(opc != 5);
	return 0;	
}

