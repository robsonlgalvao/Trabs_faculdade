<?php
    include('confereLogado.php');
?>
<html>
    <head>
        <meta charset="utf-8">
    </head>
<?php

    include('conexao.php');
    $id=$_REQUEST['id'];
    $sql = "SELECT id,nome,autor,tipo FROM musicas WHERE id=".$id;
    $umaunicamusica = $conn->query($sql);
    $linha = $umaunicamusica->fetch_assoc();
    $id = $linha["id"];
    $nome = $linha["nome"];
    $autor = $linha["autor"];
    $tipo = $linha["tipo"];
?>
    <body>
        <center>
            <form action="updateMusica.php"> 
                Id<br>
                <input type="number" name="idForm" READONLY 
                value="<?php print $id; ?>"><br>
                Nome<br>
                <input type="text" name="nomeForm" value="<?php print $nome; ?>"><br>
                <br>
                Autor<br>
                <input type="text" name="autorForm" value="<?php print $autor; ?>"><br>
                <br>
                Tipo<br>
                <input type="text" name="tipoForm" value="<?php print $tipo; ?>"><br>
                <br>
                <input type="submit">
            </form>
            <a href="musicas.php">Voltar</a>
        </center>
    </body>
</html>