<?php
    include('confereLogado.php');
?>
<html>
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <center>
            <h2>Incluir música</h2>
            <form action="incluiMusica.php"> 
                Id<br>
                <input type="number" name="idForm"><br>
                Nome<br>
                <input type="text" name="nomeForm"><br>
                <br>
                Autor<br>
                <input type="text" name="autorForm"><br>
                <br>
                Tipo<br>
                <input type="text" name="tipoForm"><br>
                <br>
                <input type="submit">
            </form>
        </center>
        <a href="musicas.php">Voltar</a>
</html>