<?php

	// servidor, usuário, senha, banco de dados
	$conn = new mysqli("localhost","id20631691_usuario02","Senha123!","id20631691_banco02");

?>