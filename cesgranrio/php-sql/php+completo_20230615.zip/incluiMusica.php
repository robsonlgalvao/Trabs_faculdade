<?php
    include('confereLogado.php');

    $id = $_REQUEST['idForm'];  // veio do form
    $nome = $_REQUEST['nomeForm'];  // veio do form
    $autor = $_REQUEST['autorForm'];  // veio do form
    $tipo = $_REQUEST['tipoForm'];  // veio do form

    $query = "INSERT INTO musicas(id,nome,autor,tipo) VALUES (".$id.",'".$nome."','".$autor."','".$tipo."');";

    include('conexao.php');

    // rodar a query
    $recordset = $conn->query($query);

    header('Location:musicas.php');
?>