<?php
    $id = $_REQUEST['idForm'];  // veio do form
    $nome = $_REQUEST['nomeForm'];  // veio do form
    $autor = $_REQUEST['autorForm'];  // veio do form
    $tipo = $_REQUEST['tipoForm'];  // veio do form

    $query = "UPDATE musicas SET nome='".$nome."', autor='".$autor."', tipo='".$tipo."' WHERE id=".$id;

    include('conexao.php');

    // rodar a query
    $recordset = $conn->query($query);

    header('Location:musicas.php');
?>