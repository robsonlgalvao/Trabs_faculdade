<html>
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <table width="100%" height="100%">
            <tr>
                <td align="center" valign="middle">
                    <form action="login.php">
                        Usuário<br>
                        <input name="usuarioForm" type="text"><br>
                        Senha<br>
                        <input name="senhaForm" type="password"><br>
                        <input type="submit" value="Ok">
                    </form>
                </td>
            </tr>
        </table>
    </body>
</html>