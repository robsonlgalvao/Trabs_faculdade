<?php
    include('confereLogado.php');

    $id = $_REQUEST['id'];  // veio do form

    $query = "DELETE FROM musicas WHERE id=".$id;

    include('conexao.php');

    // rodar a query
    $recordset = $conn->query($query);

    header('Location:musicas.php');

?>