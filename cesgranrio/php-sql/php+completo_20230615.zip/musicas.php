<?php
    include('confereLogado.php');
?>
<html>
    <body>
    <style> body { font-family: calibri; }</style>

<?php
    print "Logado: ".$logado."<br>";

	$sql = "SELECT id, nome, autor, tipo FROM musicas ORDER BY id";

    include('conexao.php');

	$recordset = $conn->query($sql);

	print "<center><h2>Lista de Músicas</h2>";
	print "Bem vindo, ".$_SESSION['nomeUsuario']."<br><br>";
	
	$admin = $_SESSION['admin'];
	if($admin==1)
	{
	    print "<a href='inserir.php'>INCLUIR MÚSICA</a><br>";
	}
	
	print "<table>";

	while($linha = $recordset->fetch_assoc())
	{
		print "<tr>";
		print "<td><a href='deleteMusica.php?id=".$linha['id']."'><img src='botao.png'></a></td>";
		print "<td><a href='atualizaMusica.php?id=".$linha['id']."'><img src='botaoupdate.png'></a></td>";
		print "<td>".$linha['id']."</td>";
		print "<td>".$linha['nome']."</td>";
		print "<td>".$linha['autor']."</td>";
		
		if($linha['tipo']=='Rock') {
		    $imagem="guitarra.png";
		    $alt="Rock";
		}
		 
		if($linha['tipo']=='Metal') {
		    $imagem="metal.png";
		    $alt="Metal";
		}
		
		print "<td><img src='".$imagem."' height='20'></td>";
    	print "</tr>";
	}
	print "</table></center>";
?>
</body>
</html>